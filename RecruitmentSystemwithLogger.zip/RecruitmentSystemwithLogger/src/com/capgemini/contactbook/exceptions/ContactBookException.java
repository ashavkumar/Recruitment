package com.capgemini.contactbook.exceptions;
@SuppressWarnings("serial")
public class ContactBookException extends Exception {
}
