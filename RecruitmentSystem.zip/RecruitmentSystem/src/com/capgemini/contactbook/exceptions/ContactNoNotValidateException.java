package com.capgemini.contactbook.exceptions;
@SuppressWarnings("serial")
public class ContactNoNotValidateException extends Exception {

}
