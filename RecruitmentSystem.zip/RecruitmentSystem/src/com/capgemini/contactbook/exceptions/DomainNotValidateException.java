package com.capgemini.contactbook.exceptions;
@SuppressWarnings("serial")
public class DomainNotValidateException extends Exception {

}
