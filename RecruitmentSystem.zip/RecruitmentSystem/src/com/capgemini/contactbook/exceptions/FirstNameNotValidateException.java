package com.capgemini.contactbook.exceptions;
@SuppressWarnings("serial")
public class FirstNameNotValidateException extends Exception {

}
