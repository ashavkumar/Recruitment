package com.capgemini.contactbook.service;
import java.sql.SQLException;
import java.util.regex.Pattern;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.dao.ContactBookDAO;
import com.capgemini.contactbook.dao.ContactBookDAOImpl;
import com.capgemini.contactbook.exceptions.ContactBookException;
import com.capgemini.contactbook.exceptions.ContactNoNotValidateException;
import com.capgemini.contactbook.exceptions.DomainNotValidateException;
import com.capgemini.contactbook.exceptions.FirstNameNotValidateException;
import com.capgemini.contactbook.exceptions.LocationNotValidateException;
public class ContactBookServiceImpl implements ContactBookService{
	private ContactBookDAO dao=new ContactBookDAOImpl();
	@SuppressWarnings("unused")
	private ContactBookDAO contactBookDAO;
	public ContactBookServiceImpl() {
		super();
		}
	public ContactBookServiceImpl(ContactBookDAO contactBookDAO) {
		super();
		this.contactBookDAO = contactBookDAO;	
	}
	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException, SQLException, ContactNoNotValidateException, FirstNameNotValidateException, LocationNotValidateException, DomainNotValidateException {
		if(Pattern.matches("[1-9][0-9]{9}",enqry.getContactNo())==false)
			throw new ContactNoNotValidateException();
		if(enqry.getfName()==null)
			throw new FirstNameNotValidateException();
		if(enqry.getpLocation()==null)
			throw new LocationNotValidateException();
		if(enqry.getpDomain()==null)
			throw new DomainNotValidateException();
			int enquiryID=dao.addEnquiry(enqry);
		return enquiryID;
	}
	@Override
	public EnquiryBean getEnquiryDetails(int EnquiryID)
			throws ContactBookException, SQLException {
			EnquiryBean bean=dao.getEnquiryDetails(EnquiryID);
		return bean;
	}
	@Override
	public boolean isValidEnquiry(EnquiryBean enqry)
			throws ContactBookException, SQLException {
		boolean flag=dao.isValidEnuiry(enqry);
		return flag;
	}

}
