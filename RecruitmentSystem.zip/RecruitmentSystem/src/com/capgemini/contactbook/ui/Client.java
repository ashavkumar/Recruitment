package com.capgemini.contactbook.ui;
import java.sql.SQLException;
import java.util.Scanner;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.exceptions.ContactBookException;
import com.capgemini.contactbook.exceptions.ContactNoNotValidateException;
import com.capgemini.contactbook.exceptions.DomainNotValidateException;
import com.capgemini.contactbook.exceptions.FirstNameNotValidateException;
import com.capgemini.contactbook.exceptions.LocationNotValidateException;
import com.capgemini.contactbook.service.ContactBookService;
import com.capgemini.contactbook.service.ContactBookServiceImpl;
public class Client {
	@SuppressWarnings("resource")
	public static void main(String[] args) throws ContactBookException, SQLException, ContactNoNotValidateException, FirstNameNotValidateException, LocationNotValidateException, DomainNotValidateException {	
		int key=0;
		ContactBookService contact=new ContactBookServiceImpl();
		Scanner s=new Scanner(System.in);
		do{
			System.out.println("*******************Global Recruitment************************");
			System.out.println("Choose an Opeartion");
			System.out.println("1. Enter Enquiry Details.");
			System.out.println("2. View Enquiry Details on Id.");
			System.out.println("3. Exit");
			 key=s.nextInt();
			s.nextLine();
			switch (key) {
			case 1:
				System.out.println("Enter first name: ");
				String firstName=s.nextLine();
				System.out.println("Enter last name: ");
				String lastName=s.nextLine();
				System.out.println("Enter contactNo: ");
				String contactNo=s.nextLine();
				System.out.println("Enter Preferred domain: ");
				String domain=s.nextLine();
				System.out.println("Enter Preferred Location: ");
				String Location=s.nextLine();
				EnquiryBean bean5=new EnquiryBean(firstName, lastName,contactNo, domain, Location);
				int EnquiryId=contact.addEnquiry(bean5);
				System.out.println("Thank You "+firstName+" "+lastName+"Your Unique Id is "+EnquiryId+" we will contact you shortly");
				break;
			case 2:
				System.out.println("Enter the Enquiry ID:");
				int enquiryId=s.nextInt();
				EnquiryBean bean6=contact.getEnquiryDetails(enquiryId);
				if(bean6==null)
					System.out.println("Sorry No Details Found");
				else
					System.out.println(bean6.toString());
				break;
			default:
				System.out.println("Thank you For selecting Us");
				}
			}while (key>0 && key <3);
	}
}
