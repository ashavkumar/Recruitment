package com.capgemini.contactbook.dao;
import java.sql.SQLException;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.exceptions.ContactBookException;
public interface ContactBookDAO {
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException, SQLException;
	public EnquiryBean getEnquiryDetails(int enquiryID) throws ContactBookException, SQLException;
	public boolean isValidEnuiry(EnquiryBean enqry) throws SQLException;
}
