package com.capgemini.contactbook.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.log4j.Logger;
import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.exceptions.ContactBookException;
import com.capgemini.contactbook.service.ContactBookServiceImpl;
import com.capgemini.contactbook.util.ConnectionProvider;
public class ContactBookDAOImpl implements ContactBookDAO{
	private Connection conn=ConnectionProvider.getDBConnection();
	private static final Logger logger = Logger.getLogger(ContactBookServiceImpl.class);
	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException, SQLException {
		try{
			conn.setAutoCommit(false);
			PreparedStatement pstmt1 = conn.prepareStatement("insert into enquiry(firstName,lastName,contactNo,domain,city) values (?,?,?,?,?)");
			pstmt1.setString(1, enqry.getfName());
			pstmt1.setString(2, enqry.getlName());
			pstmt1.setString(3, enqry.getContactNo());
			pstmt1.setString(4, enqry.getpDomain());
			pstmt1.setString(5, enqry.getpLocation());
			pstmt1.executeUpdate();

			PreparedStatement pstmt2 = conn.prepareStatement("select max(enqryId) from enquiry");
			ResultSet rs = pstmt2.executeQuery();
			rs.next();
			int EnquiryId = rs.getInt(1);
			conn.commit();
			return EnquiryId;
		}catch (SQLException e){
			logger.error(e.getMessage()+" "+e.getCause()+" "+e.getErrorCode());
			e.printStackTrace();
			conn.rollback();
			throw e;
		}
		finally{
			conn.setAutoCommit(true);
		}
	}

	@Override
	public EnquiryBean getEnquiryDetails(int enquiryID)
			throws ContactBookException, SQLException {
		try{
		PreparedStatement pstmt1 = conn.prepareStatement("Select * from  enquiry where  enqryId="+enquiryID);
		ResultSet RS = pstmt1.executeQuery();
		if(RS.next()) {
			int enquiryId=RS.getInt("enqryId");
			String firstName=RS.getString("firstName");
			String lastName=RS.getString("lastName");
			String contactNo=RS.getString("contactNo");
			String domain=RS.getString("domain");
			String city=RS.getString("city");
			EnquiryBean bean = new EnquiryBean(enquiryId,firstName,lastName,contactNo,domain,city);
			return bean;
		}
		}catch(SQLException e){
			e.printStackTrace();
			logger.error(e.getMessage()+" "+e.getCause()+" "+e.getErrorCode());
		}
		return null;
	}

	@Override
	public boolean isValidEnuiry(EnquiryBean enqry) throws SQLException {
		try{
			conn.setAutoCommit(false);

			PreparedStatement pstmt2 = conn.prepareStatement("select enqryId from enquiry where enqryId="+enqry.getEmqryId());
			ResultSet rs = pstmt2.executeQuery();
			if(rs!=null){
				rs.next();
				@SuppressWarnings("unused")
				int EnquiryId = rs.getInt(1);
				return true;
			}
			conn.commit();
		}catch (SQLException e){
			e.printStackTrace();
			conn.rollback();
			logger.error(e.getMessage()+" "+e.getCause()+" "+e.getErrorCode());
			throw e;
		}
		finally{
			conn.setAutoCommit(true);
		}
		return false;
	}
}