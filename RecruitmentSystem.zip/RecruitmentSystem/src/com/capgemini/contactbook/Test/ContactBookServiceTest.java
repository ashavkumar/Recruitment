package com.capgemini.contactbook.Test;
import static org.junit.Assert.*;
import java.sql.SQLException;
import java.util.ArrayList;
import org.easymock.EasyMock;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.dao.ContactBookDAO;
import com.capgemini.contactbook.exceptions.ContactBookException;
import com.capgemini.contactbook.exceptions.ContactNoNotValidateException;
import com.capgemini.contactbook.exceptions.DomainNotValidateException;
import com.capgemini.contactbook.exceptions.FirstNameNotValidateException;
import com.capgemini.contactbook.exceptions.LocationNotValidateException;
import com.capgemini.contactbook.service.ContactBookService;
import com.capgemini.contactbook.service.ContactBookServiceImpl;
public class ContactBookServiceTest {
	private static ContactBookService contactBookService;
	private static ContactBookDAO contactBookDAO;
	@BeforeClass
	public static void setUpTestEnv() {
		contactBookDAO = EasyMock.mock(ContactBookDAO.class);
		contactBookService = new ContactBookServiceImpl(contactBookDAO);
	}
/*	@Before
	public void setUpTestData() {	
		EnquiryBean bean1 = new EnquiryBean(1001, "Satish", "Mahajan", "7050312950", "Pune", "Java");
		EnquiryBean bean2 =new EnquiryBean(1002,"Ayush", "Mahajan", "9875894621", "Noida", "Python");
		ArrayList<EnquiryBean> enquiryList = new ArrayList<>();
		enquiryList.add(bean1);
		enquiryList.add(bean2);	
		EnquiryBean bean3 =new EnquiryBean(1003,"Keshav", "Mahajan", "9858994521", "Banglore", "C++");
		EasyMock.expect(contactBookDAO.getEnquiryDetails(1001)).andReturn(bean1);
		EasyMock.expect(contactBookDAO.getEnquiryDetails(1002)).andReturn(bean2);
		EasyMock.expect(contactBookDAO.getEnquiryDetails(1010)).andReturn(null);
		EasyMock.expect(contactBookDAO.addEnquiry(bean3)).andReturn(bean3);
	}*/
	@Test(expected = ContactBookException.class)
	public void testGetEnquiryDataForInvalidEnquiryId() throws ContactBookException, SQLException{
		contactBookService.getEnquiryDetails(1234);
		EasyMock.verify(contactBookDAO.getEnquiryDetails(1234));
	}
	@Test
	public void testGetAssociateDataForValidAssociateId() throws ContactBookException, SQLException{
		EnquiryBean expectedAssociate = new EnquiryBean(1011,"Satish", "Mahajan", "8877995566", "Pune", "C++");
		EnquiryBean actualAssociate = contactBookService.getEnquiryDetails(1011);	
		EasyMock.verify(contactBookDAO.getEnquiryDetails(1011));
		assertEquals(expectedAssociate, actualAssociate);
	}
	@Test
	public void testAcceptEnquiryDetailsForValidData() throws ContactBookException, SQLException, ContactNoNotValidateException, FirstNameNotValidateException, LocationNotValidateException, DomainNotValidateException {
		int expectedAssociateId = 1003;
		EnquiryBean enqry=new EnquiryBean("Nilesh","Kumar","7050312950","Pune","Java");
		int actualAssociateId = contactBookService.addEnquiry(enqry);
		assertEquals(expectedAssociateId, actualAssociateId);
	}
	@Test(expected = ContactBookException.class)
	public void testCalculateNetSalaryForInvalidAssociateId() throws ContactBookException, SQLException {
		contactBookService.getEnquiryDetails(12365);
	}
	@Test
	public void testGetAllAssociatesDetails() {
		EnquiryBean bean1 = new EnquiryBean(1001, "Satish", "Mahajan", "7050312950", "Pune", "C");
		EnquiryBean bean2 =new EnquiryBean(1002,"Ayush", "Mahajan", "7755889966", "Agra", "C++");
		ArrayList<EnquiryBean> expectedbeanList = new ArrayList<>();
		expectedbeanList.add(bean1);
		expectedbeanList.add(bean2);	
	}
	@After
	public void tearDownTestData() {
	}
	@AfterClass
	public static void tearDownTestEnv() {
		contactBookService=null;
		contactBookDAO=null;
	}
}
