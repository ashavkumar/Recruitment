package com.capgemini.contactbook.bean;
public class EnquiryBean {
	private int emqryId;
	private  String fName;
	private String lName;
	private String contactNo;
	private String pLocation;
	private String pDomain;
	public EnquiryBean() {
		super();
	}
	public EnquiryBean(int emqryId, String fName, String lName,
			String contactNo, String pLocation, String pDomain) {
		super();
		this.emqryId = emqryId;
		this.fName = fName;
		this.lName = lName;
		this.contactNo = contactNo;
		this.pLocation = pLocation;
		this.pDomain = pDomain;
	}
	public EnquiryBean(String string, String string2, String string3,
			String string4, String string5) {
		this.fName = string;
		this.lName = string2;
		this.contactNo = string3;
		this.pLocation = string4;
		this.pDomain = string5;
	}
	public int getEmqryId() {
		return emqryId;
	}
	public void setEmqryId(int emqryId) {
		this.emqryId = emqryId;
	}
	public String getfName() {
		return fName;
	}
	public void setfName(String fName) {
		this.fName = fName;
	}
	public String getlName() {
		return lName;
	}
	public void setlName(String lName) {
		this.lName = lName;
	}
	public String getContactNo() {
		return contactNo;
	}
	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}
	public String getpLocation() {
		return pLocation;
	}
	public void setpLocation(String pLocation) {
		this.pLocation = pLocation;
	}
	public String getpDomain() {
		return pDomain;
	}
	public void setpDomain(String pDomain) {
		this.pDomain = pDomain;
	}
	@Override
	public String toString() {
		return "EnquiryBean [emqryId=" + emqryId + ", fName=" + fName
				+ ", lName=" + lName + ", contactNo=" + contactNo
				+ ", pLocation=" + pLocation + ", pDomain=" + pDomain + "]";
	}
}
